package week1.day1;

public class Bike {

	public static void main(String[] args) {
		CarAssignment obj = new CarAssignment();
		obj.applyBreak();
		obj.soundHorn();
		

	}

}
