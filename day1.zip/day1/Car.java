package week1.day1;

public class Car {
	public static void main(String[] args) {
		System.out.println("Hello Beautiful World");
	}

}
