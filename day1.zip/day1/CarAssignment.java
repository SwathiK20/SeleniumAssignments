package week1.day1;

public class CarAssignment {

	public void applyBreak() {
		System.out.println("Applied break");
	}
	public void soundHorn() {
		
		System.out.println("Sound horn");

	}
	public static class Bike {
	

}
}
