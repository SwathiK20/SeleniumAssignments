package week1.day1;

public class Student {

	String studentName ="Swathi" ;
	int rollNo =445544;
	String collegeName ="JNTU University";	
	int markScored =80;
	int cgpa = 8;

}
